#ifndef _BAROMETER18_H_
#define _BAROMETER18_H_

#include <Arduino.h>
#include <Wire.h>

static uint16_t dig_T1, dig_P1;
static int16_t dig_T2, dig_T3, dig_P2, dig_P3, dig_P4, dig_P5;
static int16_t dig_P6, dig_P7, dig_P8, dig_P9;

static float AltitudeBarometer, AltitudeBarometerStartUp;

static float AltitudeKalman, VelocityVerticalKalman;

bool BarometerConfig (TwoWire &Wire);
bool BarometerCalib (TwoWire &Wire, float& AltitudeBarometerStartUp, float& AltitudeBarometer, uint16_t& dig_T1, uint16_t& dig_P1, int16_t& dig_T2,
int16_t& dig_T3, int16_t& dig_P2, int16_t& dig_P3, int16_t& dig_P4, int16_t& dig_P5, int16_t& dig_P6, int16_t& dig_P7, int16_t& dig_P8, int16_t& dig_P9);
void BarometerSignals (TwoWire &Wire, float& AltitudeBarometer, uint16_t dig_T1, uint16_t dig_P1, int16_t dig_T2, int16_t dig_T3, int16_t dig_P2,
int16_t dig_P3, int16_t dig_P4, int16_t dig_P5, int16_t dig_P6, int16_t dig_P7, int16_t dig_P8, int16_t dig_P9);

void BarometerSignals (TwoWire &Wire, float& AltitudeBarometer, float AltitudeBarometerStartUp, uint16_t dig_T1, uint16_t dig_P1, int16_t dig_T2,
int16_t dig_T3, int16_t dig_P2, int16_t dig_P3, int16_t dig_P4, int16_t dig_P5, int16_t dig_P6, int16_t dig_P7, int16_t dig_P8, int16_t dig_P9);

#endif
