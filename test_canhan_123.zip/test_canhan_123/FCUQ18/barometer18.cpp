
#include "barometer18.h"

bool BarometerConfig (TwoWire &Wire)
{
  Wire.beginTransmission (0x76);
  Wire.write (0xF4);
  Wire.write (0x57);
  Wire.endTransmission ();

  Wire.beginTransmission (0x76);
  Wire.write (0xF5);
  Wire.write (0x14);
  Wire.endTransmission ();

  Serial.println ("Barometer has been setup!");

  return (1);
}

bool BarometerCalib (TwoWire &Wire, float& AltitudeBarometerStartUp, float& AltitudeBarometer, uint16_t& dig_T1, uint16_t& dig_P1, int16_t& dig_T2,
int16_t& dig_T3, int16_t& dig_P2, int16_t& dig_P3, int16_t& dig_P4, int16_t& dig_P5, int16_t& dig_P6, int16_t& dig_P7, int16_t& dig_P8, int16_t& dig_P9)
{
  Serial.println ("Calibrating Barometer!");
  uint8_t Data[24], i = 0;
  Wire.beginTransmission (0x76);
  Wire.write (0x88);
  Wire.endTransmission ();
  Wire.requestFrom (0x76, 24);

  while (Wire.available ())
  {
    Data[i] = Wire.read ();
    i ++;
  }
  
  dig_T1 = (Data[1] << 8) | Data[0];
  dig_T2 = (Data[3] << 8) | Data[2];
  dig_T3 = (Data[5] << 8) | Data[4];
  dig_P1 = (Data[7] << 8) | Data[6];
  dig_P2 = (Data[9] << 8) | Data[8];
  dig_P3 = (Data[11]<< 8) | Data[10];
  dig_P4 = (Data[13]<< 8) | Data[12];
  dig_P5 = (Data[15]<< 8) | Data[14];
  dig_P6 = (Data[17]<< 8) | Data[16];
  dig_P7 = (Data[19]<< 8) | Data[18];
  dig_P8 = (Data[21]<< 8) | Data[20];
  dig_P9 = (Data[23]<< 8) | Data[22];
  delay(250);

  for (uint16_t j = 0; j < 2000; j ++)
  {
    BarometerSignals (Wire, AltitudeBarometer, dig_T1, dig_P1, dig_T2, dig_T3, dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9);
    AltitudeBarometerStartUp += AltitudeBarometer;
    delay (1);
  }

  AltitudeBarometerStartUp /= 2000;
  
  return (1);
}

void BarometerSignals (TwoWire &Wire, float& AltitudeBarometer, uint16_t dig_T1, uint16_t dig_P1, int16_t dig_T2, int16_t dig_T3, int16_t dig_P2,
int16_t dig_P3, int16_t dig_P4, int16_t dig_P5, int16_t dig_P6, int16_t dig_P7, int16_t dig_P8, int16_t dig_P9)
{
  Wire.beginTransmission (0x76);
  Wire.write (0xF7);
  Wire.endTransmission ();
  Wire.requestFrom(0x76, 6);

  uint32_t press_msb = Wire.read ();
  uint32_t press_lsb = Wire.read ();
  uint32_t press_xlsb = Wire.read ();
  uint32_t temp_msb = Wire.read ();
  uint32_t temp_lsb = Wire.read ();
  uint32_t temp_xlsb = Wire.read ();

  unsigned long int adc_P = (press_msb << 12) | (press_lsb << 4) | (press_xlsb >> 4);
  unsigned long int adc_T = (temp_msb << 12) | (temp_lsb << 4) | (temp_xlsb >> 4);

  signed long int var1, var2;
  var1 = ((((adc_T >> 3) - ((signed long int ) dig_T1 << 1))) * ((signed long int ) dig_T2)) >> 11;
  var2 = (((((adc_T >> 4) - ((signed long int ) dig_T1)) * ((adc_T >> 4) - ((signed long int ) dig_T1))) >> 12) * ((signed long int ) dig_T3)) >> 14;
  signed long int t_fine = var1 + var2;

  unsigned long int p;
  var1 = (((signed long int ) t_fine) >> 1) - (signed long int ) 64000;
  var2 = (((var1 >> 2) * (var1 >> 2)) >> 11) * ((signed long int ) dig_P6);
  var2 = var2 + ((var1 * ((signed long int) dig_P5)) << 1);
  var2 = (var2 >> 2) + (((signed long int) dig_P4) << 16);
  var1 = (((dig_P3 * (((var1 >> 2) * (var1 >> 2)) >> 13)) >> 3) + ((((signed long int ) dig_P2) * var1) >> 1)) >> 18;
  var1 = ((((32768 + var1)) * ((signed long int ) dig_P1)) >> 15);

  if (var1 == 0) {p = 0;}
  p = (((unsigned long int) (((signed long int ) 1048576) - adc_P) - (var2 >> 12))) * 3125;

  if (p < 0x80000000) {p = (p << 1) / ((unsigned long int) var1);}
  else {p = (p / (unsigned long int) var1) * 2;}

  var1 = (((signed long int) dig_P9) * ((signed long int) (((p >> 3) * (p >> 3)) >> 13))) >> 12;
  var2 = (((signed long int)(p >> 2)) * ((signed long int ) dig_P8)) >> 13;
  p = (unsigned long int) ((signed long int ) p + ((var1 + var2 + dig_P7) >> 4));  

  double pressure = (double) p / 100;
  AltitudeBarometer = 44330 * (1 - pow (pressure / 1013.25, 1 / 5.255)) * 100;
}

void BarometerSignals (TwoWire &Wire, float& AltitudeBarometer, float AltitudeBarometerStartUp, uint16_t dig_T1, uint16_t dig_P1, int16_t dig_T2,
int16_t dig_T3, int16_t dig_P2, int16_t dig_P3, int16_t dig_P4, int16_t dig_P5, int16_t dig_P6, int16_t dig_P7, int16_t dig_P8, int16_t dig_P9)
{
  Wire.beginTransmission (0x76);
  Wire.write (0xF7);
  Wire.endTransmission ();
  Wire.requestFrom(0x76, 6);

  uint32_t press_msb = Wire.read ();
  uint32_t press_lsb = Wire.read ();
  uint32_t press_xlsb = Wire.read ();
  uint32_t temp_msb = Wire.read ();
  uint32_t temp_lsb = Wire.read ();
  uint32_t temp_xlsb = Wire.read ();

  unsigned long int adc_P = (press_msb << 12) | (press_lsb << 4) | (press_xlsb >> 4);
  unsigned long int adc_T = (temp_msb << 12) | (temp_lsb << 4) | (temp_xlsb >> 4);

  signed long int var1, var2;
  var1 = ((((adc_T >> 3) - ((signed long int ) dig_T1 << 1))) * ((signed long int ) dig_T2)) >> 11;
  var2 = (((((adc_T >> 4) - ((signed long int ) dig_T1)) * ((adc_T >> 4) - ((signed long int ) dig_T1))) >> 12) * ((signed long int ) dig_T3)) >> 14;
  signed long int t_fine = var1 + var2;

  unsigned long int p;
  var1 = (((signed long int ) t_fine) >> 1) - (signed long int ) 64000;
  var2 = (((var1 >> 2) * (var1 >> 2)) >> 11) * ((signed long int ) dig_P6);
  var2 = var2 + ((var1 * ((signed long int) dig_P5)) << 1);
  var2 = (var2 >> 2) + (((signed long int) dig_P4) << 16);
  var1 = (((dig_P3 * (((var1 >> 2) * (var1 >> 2)) >> 13)) >> 3) + ((((signed long int ) dig_P2) * var1) >> 1)) >> 18;
  var1 = ((((32768 + var1)) * ((signed long int ) dig_P1)) >> 15);

  if (var1 == 0) {p = 0;}
  p = (((unsigned long int) (((signed long int ) 1048576) - adc_P) - (var2 >> 12))) * 3125;

  if (p < 0x80000000) {p = (p << 1) / ((unsigned long int) var1);}
  else {p = (p / (unsigned long int) var1) * 2;}

  var1 = (((signed long int) dig_P9) * ((signed long int) (((p >> 3) * (p >> 3)) >> 13))) >> 12;
  var2 = (((signed long int)(p >> 2)) * ((signed long int ) dig_P8)) >> 13;
  p = (unsigned long int) ((signed long int ) p + ((var1 + var2 + dig_P7) >> 4));  

  double pressure = (double) p / 100;
  AltitudeBarometer = 44330 * (1 - pow (pressure / 1013.25, 1 / 5.255)) * 100 - AltitudeBarometerStartUp;  
}

