#ifndef _FCUQ18_H_
#define _FCUQ18_H_

#include <Arduino.h>
#include <Wire.h>
#include "imu18.h"
#include "datacom18.h"
#include "pid18.h"
#include "escpwm18.h"
#include "barometer18.h"
#include "rc18.h"


#define   CAP_TIME_GPIO                 A2
#define   LED_RECEIVING_POWER           A3 //Pg.25
#define   LED_BEGINNING_SETUP           A4 //Pg.25
#define   LED_OPERATION_PROCESS         A5 //Pg.25
#define   IIC                           Wire

static SECMEMS EEprom;

static bool CapTime = 0;
static uint32_t LoopTimer;

bool FCUQconfig (TwoWire &Wire, uint16_t EnaOffGPIO, uint16_t CapGPIO, uint16_t LedBegGPIO, uint16_t LedReceiGPIO, uint16_t LedOpeGPIO, bool CapTime);
bool UpdateQuadData (float* ReceiverValue, uint8_t* QuadBuff, uint8_t* QuadData, uint16_t* DutyRef, float KalmanAngleRoll, float KalmanAnglePitch, float RateYaw, float InputThrottle,
uint16_t RCDataPosMin, uint16_t DataSize);

bool AssignMotorInput (float* ReceiverValue, float InputRoll, float InputPitch, float InputYaw, float& InputThrottle, float& MotorInput1, float& MotorInput2, float& MotorInput3, float& MotorInput4,
float& PrevErrorRateRoll, float& PrevErrorRatePitch, float& PrevErrorRateYaw, float& PrevItermRateRoll, float& PrevItermRatePitch, float& PrevItermRateYaw,
float& PrevErrorAngleRoll, float& PrevErrorAnglePitch, float& PrevItermAngleRoll, float& PrevItermAnglePitch, float& PrevErrorVelocityVertical, float& PrevItermVelocityVertical);

#endif
