#include "datacom18.h"

bool DataComConfig(Uart& UCOM, uint32_t UARTBaudrate) {
  UCOM.begin(UARTBaudrate);
  Serial.println("UART1 port has been initialized!");
  return (1);
}

bool CheckingRCVals() {
  while (1) {
    if (newFrame) {
      uint16_t ch[8];

      noInterrupts();
      for (int i = 0; i < 8; i++)
        ch[i] = ppm[i];
      newFrame = false;

      interrupts();
      if (ch[0] > 1490 && ch[0] < 1500) /*ch1*/
        if (ch[1] > 1490 && ch[1] < 1500) /*ch2*/
          if (ch[2] > 990 && ch[2] < 1010) /*ch3*/
            if (ch[3] > 1490 && ch[3] < 1500) /*ch4*/
              break;
    }
  }
  return (1);
}
// ("CH1: "); Serial.print(ch[0]);