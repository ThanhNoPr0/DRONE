// 24C256 EEPROM driver header file
#ifndef _SECMEMS18_H_
#define _SECMEMS18_H_
#include <Arduino.h>
#include <Wire.h>

#define     SECMEMS_ADD     0x50


class SECMEMS
{
public: 
  SECMEMS (uint8_t Address);
  SECMEMS ();
  bool Begin (TwoWire &Wire);
  bool Begin ();
  void Write (TwoWire &Wire, uint16_t WriteAddress, uint8_t* Data, uint8_t Len);
  void Read (TwoWire &Wire, uint16_t ReadAddress, uint8_t* Data, uint8_t Len);

private:
	uint8_t _address;

};


#endif