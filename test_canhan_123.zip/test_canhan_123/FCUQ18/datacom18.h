#ifndef _DATACOM18_H_
#define _DATACOM18_H_

#include <Arduino.h>

#include "rc18.h"


/*RC CHANNEL*/
#define   DATA_BLOCK            40
#define   RC_CHANNELS           6
#define   RC_DATA_BLOCK         2*RC_CHANNELS

#define   RC_DATA_POS_MIN       3
#define   RC_CHANNEL_ROLL       3
#define   RC_CHANNEL_PITCH      7
#define   RC_CHANNEL_YAW        15
#define   RC_CHANNEL_THROTTLE   11


/*UART COMMUNICATION*/
#define   UCOM                 Serial1
#define   UCOM_BAUDRATE        9600

bool DataComConfig (Uart& UCOM, uint32_t UARTBaudrate);
bool CheckingRCVals (); 
#endif
