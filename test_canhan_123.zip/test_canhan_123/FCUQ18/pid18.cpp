
#include "pid18.h"

void PIDequation (float* PIDReturn, float Error, float P , float I, float D, float PrevError, float PrevIterm, float TimeStep)
{
  float Pterm = P * Error;
  float Iterm = PrevIterm + I * (Error + PrevError) * TimeStep / 2;
  if (Iterm > 400) Iterm = 400;
  else if (Iterm < -400) Iterm = -400;
  float Dterm = D * (Error - PrevError) / TimeStep;
  float PIDOutput = Pterm + Iterm + Dterm;
  if (PIDOutput > 400) PIDOutput = 400;
  else if (PIDOutput < -400) PIDOutput = -400;
  PIDReturn[0] = PIDOutput;
  PIDReturn[1] = Error;
  PIDReturn[2] = Iterm;
}

void ResetPID (float& PrevErrorRateRoll, float& PrevErrorRatePitch, float& PrevErrorRateYaw, float& PrevItermRateRoll, float& PrevItermRatePitch, float& PrevItermRateYaw,
float& PrevErrorAngleRoll, float& PrevErrorAnglePitch, float& PrevItermAngleRoll, float& PrevItermAnglePitch, float& PrevErrorVelocityVertical, float& PrevItermVelocityVertical)
{
  PrevErrorRateRoll = 0;
  PrevErrorRatePitch = 0;
  PrevErrorRateYaw = 0;
  PrevItermRateRoll = 0;
  PrevItermRatePitch = 0;
  PrevItermRateYaw = 0;

  PrevErrorAngleRoll = 0; PrevErrorAnglePitch = 0;
  PrevItermAngleRoll = 0; PrevItermAnglePitch = 0;

  PrevErrorVelocityVertical = 0; PrevItermVelocityVertical = 0;
}

void ResetAccPID (float& PrevErrorAccRoll, float& PrevItermAccRoll)
{
  PrevErrorAccRoll = 0;
  PrevItermAccRoll = 0;
}