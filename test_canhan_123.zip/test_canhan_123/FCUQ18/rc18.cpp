#include "rc18.h"
#define UCOM Serial1
volatile uint16_t ppm[8] = {0};
volatile uint8_t channel = 0;
volatile unsigned long lastTime = 0;
volatile bool newFrame = false;

const int ppmPin = A1;

void rcConfig() {
  pinMode(ppmPin, INPUT);   
  attachInterrupt(digitalPinToInterrupt(ppmPin), ppmISR, RISING);
}

void ppmISR() {
  unsigned long now = micros();
  unsigned long diff = now - lastTime;
  lastTime = now;

  if (diff > 3000) {
    if (channel >= 4) {
      newFrame = true;
    }
    channel = 0;
  } else {
    if (channel < 8) {
      ppm[channel] = diff;
      channel++;
    }
  }
}


// void loop() {
//   if (newFrame) {
//     uint16_t ch[8];

//     noInterrupts();
//     for (int i = 0; i < 8; i++) {
//       ch[i] = ppm[i];
//     }
//     newFrame = false;
//     interrupts();

//     Serial.print("CH1: "); Serial.print(ch[0]);
//     Serial.print(" | CH2: "); Serial.print(ch[1]);
//     Serial.print(" | CH3: "); Serial.print(ch[2]);
//     Serial.print(" | CH4: "); Serial.print(ch[3]);
//     Serial.print(" | CH5: "); Serial.print(ch[4]);
//     Serial.print(" | CH6: "); Serial.print(ch[5]);
//     Serial.print(" | CH7: "); Serial.print(ch[6]);
//     Serial.print(" | CH8: "); Serial.println(ch[7]);
//     UCOM.println(ch[1]);
  

//   }
// }
