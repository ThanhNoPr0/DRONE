#ifndef _ESCPWM18_H_
#define _ESCPWM18_H_

#include <Arduino.h>

#define   PWM_CHANNELS         4
#define   MOSFET_PIN           2
#define   PWM_CH0_PIN          4
#define   PWM_CH1_PIN          5
#define   PWM_CH2_PIN          6
#define   PWM_CH3_PIN          7

static uint16_t DutyCyc[PWM_CHANNELS] = {0, 0, 0, 0};                      //Duty Cycle: PWMH0 channel, PWMH1 channel, PWMH2 channel, PWMH3 channel, -- channel, -- channel
static uint16_t DutyRef[PWM_CHANNELS] = {0, 0, 0, 0};                       //Duty Cycle: PWMH0 channel, PWMH1 channel, PWMH2 channel, PWMH3 channel, -- channel, -- channel

bool PWMPortReset ();
bool ESCPWMConfig ();
bool ESCcalib ();
bool UpdatePWMDutyCycle (uint32_t CDTYUPD0, uint32_t CDTYUPD1, uint32_t CDTYUPD2, uint32_t CDTYUPD3);
void UpdateESCSimultaneous (uint16_t* DutyCyc, uint16_t* DutyRef, uint16_t PWMChannel);
bool UpdatePWMDutyCycleChannel (uint16_t Channel, uint32_t CDTYUPD);

#endif

