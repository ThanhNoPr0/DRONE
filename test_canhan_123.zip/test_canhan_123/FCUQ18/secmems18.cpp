//AT24C256 driver CPP file
#include "secmems18.h"

SECMEMS::SECMEMS (uint8_t Address)
{
	_address = Address;
}

SECMEMS::SECMEMS ()
{
	_address = SECMEMS_ADD;
}

bool SECMEMS::Begin (TwoWire &Wire)
{
  Wire.begin();
  return (1);
}

bool SECMEMS::Begin ()
{
  return (1);
}

void SECMEMS::Write (TwoWire &Wire, uint16_t WriteAddress, uint8_t* Data, uint8_t Len)
{

	Wire.beginTransmission (_address);
	Wire.write ((byte) (WriteAddress & 0xFF00) >> 8);
	Wire.write ((byte) (WriteAddress & 0x00FF));

	for (uint8_t i = 0; i < Len; i ++) Wire.write (Data[i]);
  
	Wire.endTransmission ();
}

void SECMEMS::Read (TwoWire &Wire, uint16_t ReadAddress, uint8_t* Data, uint8_t Len)
{

	Wire.beginTransmission (_address);
	Wire.write ((byte) (ReadAddress & 0xFF00) >> 8);
	Wire.write ((byte) (ReadAddress & 0x00FF));
	Wire.endTransmission ();

	Wire.requestFrom (_address, Len);

	for (int i = 0; i < Len; i++) if (Wire.available ()) Data[i] = Wire.read();

}

