#ifndef _IMU18_H_
#define _IMU18_H_

#include <Arduino.h>
#include <Wire.h>
#include "secmems18.h"
#include "BasicLinearAlgebra.h"
using namespace BLA;

#define   ENABLE_OFFSET_PIN                 A6
#define   IMU_OFFSETS_SECMEMS_FIRST_ADD     0
#define   IMU_CHANNELS                      6


static float RateRoll, RatePitch, RateYaw;
static float RateCalibrationRoll, RateCalibrationPitch, RateCalibrationYaw;
static uint16_t RateCalibrationNumber;

static float AccX, AccY, AccZ;
static float AccCalibrationRoll, AccCalibrationPitch, AccCalibrationYaw;
static float AngleRoll, AnglePitch;

static float KalmanAngleRoll = 0, KalmanUncertaintyAngleRoll = 2 * 2;
static float KalmanAnglePitch = 0, KalmanUncertaintyAnglePitch = 2 * 2;
static float Kalman1DOutput[] = {0, 0};

static float AccZInertial;
static float VelocityVertical;

void MPU6050Config (TwoWire &Wire);
void GyroSignals (TwoWire &Wire, float& RateRoll, float& RatePitch, float& RateYaw, float& AccX, float& AccY, float& AccZ);
void GyroSignals (TwoWire &Wire, float& RateRoll, float& RatePitch, float& RateYaw, float& RateCalibrationRoll, float& RateCalibrationPitch, float& RateCalibrationYaw,
float& AccX, float& AccY, float& AccZ, float& AccCalibrationRoll, float& AccCalibrationPitch, float& AccCalibrationYaw, float& AngleRoll, float& AnglePitch);
void IMUCalibrationFunc (TwoWire &Wire, SECMEMS Rom, uint16_t RomFirstAdd, uint16_t IMUChannels, uint16_t EnaOffGPIO, uint16_t& RateCalibrationNumber, float& RateRoll,
float& RatePitch, float& RateYaw, float& RateCalibrationRoll, float& RateCalibrationPitch, float& RateCalibrationYaw, float& AccX, float& AccY, float& AccZ,
float& AccCalibrationRoll, float& AccCalibrationPitch, float& AccCalibrationYaw);

bool StoringCalibVals (TwoWire &Wire, SECMEMS Rom, int16_t* Offsets, uint16_t RomFirstAdd, uint16_t IMUChannels);
bool RequestCalibVals (TwoWire &Wire, SECMEMS Rom, int16_t* Offsets, uint16_t RomFirstAdd, uint16_t IMUChannels);

void Kalman1DFilter (float* Kalman1DOutput, float KalmanState, float KalmanUncertainty, float KalmanInput, float KalmanMeasurement, float TimeStep);

bool CalculAccZInertial (float& AccZInertial, float AnglePitch, float AngleRoll, float AccX, float AccY, float AccZ);

static BLA::Matrix<2,2> F; static BLA::Matrix<2,1> G;
static BLA::Matrix<2,2> P; static BLA::Matrix<2,2> Q;
static BLA::Matrix<2,1> S; static BLA::Matrix<1,2> H;
static BLA::Matrix<2,2> I; static BLA::Matrix<1,1> Acc;
static BLA::Matrix<2,1> K; static BLA::Matrix<1,1> R;
static BLA::Matrix<1,1> L; static BLA::Matrix<1,1> M;

void Kalman2DFilterSetup (BLA::Matrix<2,2>& F, BLA::Matrix<2,1>& G, BLA::Matrix<1,2>& H, BLA::Matrix<2,2>& I, BLA::Matrix<2,2>& Q,
BLA::Matrix<1,1>& R, BLA::Matrix<2,2>& P, BLA::Matrix<2,1>& S);

void Kalman2DFilter (BLA::Matrix<1,1>& Acc, float AccZInertial, BLA::Matrix<2,1>& S, BLA::Matrix<2,2> F, BLA::Matrix<2,1> G, BLA::Matrix<2,2>& P, BLA::Matrix<2,2> Q,
BLA::Matrix<1,1>& L, BLA::Matrix<1,2> H, BLA::Matrix<1,1> R, BLA::Matrix<2,1>& K, BLA::Matrix<1,1>& M, float AltitudeBarometer, float& AltitudeKalman,
float& VelocityVerticalKalman, BLA::Matrix<2,2> I);

#define   LPF_CUT_OFF_FRE_IMU           2 * PI * 10 //Cut-off frequency of LPF is 10Hz
static float FilteredAcc[2], RawAcc[2];
bool LPFuncIMU (float* LPFvalsIMU, float* DataIMU, float TimeStep, float const OmeraZero);

#endif
