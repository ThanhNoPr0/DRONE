#ifndef _rc18_H_
#define _rc18_H_

#include <Arduino.h>

extern volatile uint16_t ppm[8];
extern volatile uint8_t channel;
extern volatile unsigned long lastTime;
extern volatile bool newFrame;
extern const int ppmPin;

void rcConfig();
void ppmISR();

#endif
