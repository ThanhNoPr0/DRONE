
#include "escpwm18.h"

bool PWMPortReset() {
  pinMode(PWM_CH0_PIN, OUTPUT);  //PWMH0
  pinMode(PWM_CH1_PIN, OUTPUT);  //PWMH1
  pinMode(PWM_CH2_PIN, OUTPUT);  //PWMH2
  pinMode(PWM_CH3_PIN, OUTPUT);  //PWMH3
  digitalWrite(PWM_CH0_PIN, HIGH);
  digitalWrite(PWM_CH1_PIN, HIGH);
  digitalWrite(PWM_CH2_PIN, HIGH);
  digitalWrite(PWM_CH3_PIN, HIGH);
  pinMode(MOSFET_PIN, OUTPUT);    // cấu hình chân mở nguồn công suất ESC
  digitalWrite(MOSFET_PIN, LOW);  // ngắt nguồn công suất ESC
  delay(2000);
  return (1);
}

bool ESCPWMConfig() {
  // =================================================================
  // BƯỚC 1: BẬT CLOCK HỆ THỐNG CHO TCC0
  // =================================================================
  PM->APBCMASK.reg |= PM_APBCMASK_TCC0;
  GCLK->CLKCTRL.reg = GCLK_CLKCTRL_ID(TCC0_GCLK_ID) | GCLK_CLKCTRL_GEN_GCLK0 | GCLK_CLKCTRL_CLKEN;
  while (GCLK->STATUS.bit.SYNCBUSY)
    ;
  // =================================================================
  // BƯỚC 2: CẤU HÌNH GHÉP CHÂN I/O (PIN MAPPING)
  // =================================================================
  // Cấu hình D4 (PB10) và D5 (PB11) -> Ngoại vi F
  PORT->Group[1].PINCFG[10].bit.PMUXEN = 1;   // PB10
  PORT->Group[1].PINCFG[11].bit.PMUXEN = 1;   // PB11
  PORT->Group[1].PMUX[5].reg = PORT_PMUX_PMUXE_F | PORT_PMUX_PMUXO_F;
  // Cấu hình D6 (PA20) và D7 (PA21) -> Ngoại vi F
  PORT->Group[0].PINCFG[20].bit.PMUXEN = 1;
  PORT->Group[0].PINCFG[21].bit.PMUXEN = 1;
  PORT->Group[0].PMUX[10].reg = PORT_PMUX_PMUXO_F | PORT_PMUX_PMUXE_F;
  // =================================================================
  // BƯỚC 3: CẤU HÌNH BỘ TIMER TCC0 ĐỂ PHÁT PWM 50HZ
  // =================================================================
  TCC0->CTRLA.bit.ENABLE = 0;
  while (TCC0->SYNCBUSY.bit.ENABLE) {}

  TCC0->WAVE.reg = TCC_WAVE_WAVEGEN_NPWM;
  while (TCC0->SYNCBUSY.bit.WAVE) {}

  // Ở tần số 50Hz (chu kỳ 20ms), nếu giữ nguyên Clock 48MHz thì
  // PER = (48,000,000 / 50) - 1 = 959,999 (Vượt quá giới hạn 24-bit của TCC0).
  // Do đó, ta cần bật bộ chia Prescaler là 16.
  TCC0->CTRLA.bit.PRESCALER = TCC_CTRLA_PRESCALER_DIV16_Val;

  // Tần số Clock mới vào Timer: 48MHz / 16 = 3,000,000 Hz
  // PER để đạt 50Hz = (3,000,000 / 50) - 1 = 59999
  TCC0->PER.reg = 59999;
  while (TCC0->SYNCBUSY.bit.PER) {}

  // Khởi tạo độ rộng xung ban đầu (Ví dụ: 1000us chuẩn để khởi động ESC)
  // Thời gian 1000us chiếm 5% chu kỳ 20ms -> 59999 * 0.05 = 3000
  TCC0->CC[0].reg = 5999;  // Điều khiển D6
  TCC0->CC[1].reg = 5999;  // Điều khiển D7
  TCC0->CC[2].reg = 5999;  // Điều khiển D4
  TCC0->CC[3].reg = 5999;  // Điều khiển D5

  while (TCC0->SYNCBUSY.bit.CC0 || TCC0->SYNCBUSY.bit.CC1 || TCC0->SYNCBUSY.bit.CC2 || TCC0->SYNCBUSY.bit.CC3) {}
  TCC0->CTRLA.bit.ENABLE = 1;
  while (TCC0->SYNCBUSY.bit.ENABLE) {}

  digitalWrite(MOSFET_PIN, HIGH);  // mở nguồn công suất cấp cho ESC

  return (1);
}

bool ESCcalib() {
  Serial.println("ESC Calib!!!");

  Serial.println(5999);
  TCC0->CC[0].reg = 5999;  // Motor 1 (D6)
  TCC0->CC[1].reg = 5999;  // Motor 2 (D7)
  TCC0->CC[2].reg = 5999;  // Motor 3 (D4)
  TCC0->CC[3].reg = 5999;  // Motor 4 (D5)
  // Chờ đồng bộ hóa cho các thanh ghi vừa đổi
  while (TCC0->SYNCBUSY.bit.CC0 || TCC0->SYNCBUSY.bit.CC1 || TCC0->SYNCBUSY.bit.CC2 || TCC0->SYNCBUSY.bit.CC3) {}
  delay(2000);

  Serial.println(2999);
  TCC0->CC[0].reg = 2999;  // Motor 1 (D6)
  TCC0->CC[1].reg = 2999;  // Motor 2 (D7)
  TCC0->CC[2].reg = 2999;  // Motor 3 (D4)
  TCC0->CC[3].reg = 2999;  // Motor 4 (D5)
  // Chờ đồng bộ hóa cho các thanh ghi vừa đổi
  while (TCC0->SYNCBUSY.bit.CC0 || TCC0->SYNCBUSY.bit.CC1 || TCC0->SYNCBUSY.bit.CC2 || TCC0->SYNCBUSY.bit.CC3) {}
  delay(2000); 
  // while (1) {}

  return (1);
}

void UpdateESCSimultaneous(uint16_t* DutyCyc, uint16_t* DutyRef, uint16_t PWMChannel) {
  // uint16_t Step = 1000;
  // float DeltaCh[PWMChannel];
  // float CDTYUPD[PWMChannel];
  // for (uint8_t i = 0; i < PWMChannel; i ++)
  // {
  //   DeltaCh[i] = ((float) DutyRef[i] - (float) DutyCyc[i]) / (float) Step;
  //   CDTYUPD[i] = (float) DutyRef[i];
  //   //Serial.print("deltaCh ");
  //   //Serial.print(i);
  //   //Serial.print(": ");
  //   //Serial.println(deltaCh[i]);
  // }
  // for (uint16_t i = 0; i < Step; i ++)
  // {
  //   //Serial.print("Step"); Serial.print(i); Serial.println(": --------------------");
  //   for (uint8_t k = 0; k < PWMChannel; k ++)
  //   {
  //     CDTYUPD[k] += (-1.0) * DeltaCh[k];
  //     //Serial.print("cdtyupd ");
  //     //Serial.print(k);
  //     //Serial.print(": ");
  //     //Serial.println(cdtyupd[k]);
  //   }
  //   UpdatePWMDutyCycle ((uint32_t) CDTYUPD[0], (uint32_t) CDTYUPD[1], (uint32_t) CDTYUPD[2], (uint32_t) CDTYUPD[3]);
  // }
  // for (uint8_t i = 0; i < PWMChannel; i ++) DutyRef[i] = (uint16_t) CDTYUPD[i] + 0;
}

bool UpdatePWMDutyCycleChannel(uint16_t channel, uint32_t value) {
  TCC0->CC[channel].reg = value;
  Serial.print("Channel ");
  Serial.print(channel);
  Serial.print(": ");
  Serial.println(value);
  return (1);
}
