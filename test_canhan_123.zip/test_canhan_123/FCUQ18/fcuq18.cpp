
#include "fcuq18.h"

bool FCUQconfig (TwoWire &Wire, uint16_t EnaOffGPIO, uint16_t CapGPIO, uint16_t LedBegGPIO, uint16_t LedReceiGPIO, uint16_t LedOpeGPIO, bool CapTime)
{
  pinMode (EnaOffGPIO, INPUT_PULLUP);
  pinMode (CapGPIO, OUTPUT);
  digitalWrite (CapGPIO, CapTime);
  pinMode (LedBegGPIO, OUTPUT);
  digitalWrite (LedBegGPIO, HIGH);
  pinMode (LedReceiGPIO, OUTPUT);
  digitalWrite (LedReceiGPIO, HIGH);
  pinMode (LedOpeGPIO, OUTPUT);

  Serial.begin (115200);
  Wire.setClock (400000);
  Wire.begin ();
  delay (250);
  return (1);
}

bool UpdateQuadData (float* ReceiverValue, uint8_t* QuadBuff, uint8_t* QuadData, uint16_t* DutyRef, float KalmanAngleRoll, float KalmanAnglePitch, float RateYaw, float InputThrottle,
uint16_t RCDataPosMin, uint16_t DataSize)
{
  uint16_t Roll = (uint16_t) ((KalmanAngleRoll + 45.0) * (1000.0 / 90.0) + 1000.0);
  uint16_t Pitch = (uint16_t) ((KalmanAnglePitch + 45.0) * (1000.0 / 90.0) + 1000.0);
  uint16_t Yaw;
  if (RateYaw > 360.0) Yaw = 2000;
  else if (RateYaw < -360.0) Yaw = 1000;
  else Yaw = (uint16_t) ((RateYaw + 360.0) * (1000.0 / 720.0) + 1000.0);

  uint16_t Throttle = (uint16_t) InputThrottle;

  QuadData[3] = Roll >> 8;
  QuadData[4] = Roll & 0xFF;
  QuadData[5] = Pitch >> 8;
  QuadData[6] = Pitch & 0xFF;
  QuadData[7] = Yaw >> 8;
  QuadData[8] = Yaw & 0xFF;
  QuadData[9] = Throttle >> 8;
  QuadData[10] = Throttle & 0xFF;

  for (uint8_t i = 15, j = 0; i < 23, j < 4; i += 2, j ++)
  {
    QuadData[i] = DutyRef[j] >> 8;
    QuadData[i + 1] = DutyRef[j] & 0xFF;
  }

  for (uint8_t i = 11, j = 4; i < 15, j < 6; i += 2, j ++)
  {
    QuadData[i] = (uint16_t) ReceiverValue[j] >> 8;
    QuadData[i + 1] = (uint8_t) ReceiverValue[j] & 0xFF;
    //Serial.print ("QuadData "); Serial.print (i); Serial.print (": "); Serial.println (QuadData[i]);
    //Serial.print ("QuadData "); Serial.print (i + 1);  Serial.print (": "); Serial.println (QuadData[i + 1]);
  }
  
  for (uint8_t i = RCDataPosMin; i < DataSize - 1; i ++) QuadBuff[i] = QuadData[i] - 0;
  return (1);
}

bool AssignMotorInput (float* ReceiverValue, float InputRoll, float InputPitch, float InputYaw, float& InputThrottle, float& MotorInput1, float& MotorInput2, float& MotorInput3, float& MotorInput4,
float& PrevErrorRateRoll, float& PrevErrorRatePitch, float& PrevErrorRateYaw, float& PrevItermRateRoll, float& PrevItermRatePitch, float& PrevItermRateYaw,
float& PrevErrorAngleRoll, float& PrevErrorAnglePitch, float& PrevItermAngleRoll, float& PrevItermAnglePitch, float& PrevErrorVelocityVertical, float& PrevItermVelocityVertical)
{
  if (InputThrottle > 1800) InputThrottle = 1800;

  MotorInput1 = InputThrottle - InputRoll - InputPitch - InputYaw;
  MotorInput2 = InputThrottle - InputRoll + InputPitch + InputYaw;
  MotorInput3 = InputThrottle + InputRoll + InputPitch - InputYaw;
  MotorInput4 = InputThrottle + InputRoll - InputPitch + InputYaw;

  if (MotorInput1 > 2000) MotorInput1 = 1999;
  if (MotorInput2 > 2000) MotorInput2 = 1999;
  if (MotorInput3 > 2000) MotorInput3 = 1999;
  if (MotorInput4 > 2000) MotorInput4 = 1999;

  uint16_t ThrottleIdle = 1080; //1180
  if (MotorInput1 < ThrottleIdle) MotorInput1 = ThrottleIdle;
  if (MotorInput2 < ThrottleIdle) MotorInput2 = ThrottleIdle;
  if (MotorInput3 < ThrottleIdle) MotorInput3 = ThrottleIdle;
  if (MotorInput4 < ThrottleIdle) MotorInput4 = ThrottleIdle;

  uint16_t ThrottleCutOff = 1000;
  if (ReceiverValue[3] < 1030)
  {
    MotorInput1 = ThrottleCutOff;
    MotorInput2 = ThrottleCutOff;
    MotorInput3 = ThrottleCutOff;
    MotorInput4 = ThrottleCutOff;
    ResetPID (PrevErrorRateRoll, PrevErrorRatePitch, PrevErrorRateYaw, PrevItermRateRoll, PrevItermRatePitch, PrevItermRateYaw,
    PrevErrorAngleRoll, PrevErrorAnglePitch, PrevItermAngleRoll, PrevItermAnglePitch, PrevErrorVelocityVertical, PrevItermVelocityVertical);
    ResetAccPID (PrevErrorAccRoll, PrevItermAccRoll);
  }

  //Serial.print ("MotorInput1: ");  Serial.println (MotorInput1);
  //Serial.print ("MotorInput2: ");  Serial.println (MotorInput2);
  //Serial.print ("MotorInput3: ");  Serial.println (MotorInput3);
  //Serial.print ("MotorInput4: ");  Serial.println (MotorInput4);
  return (1);
}


