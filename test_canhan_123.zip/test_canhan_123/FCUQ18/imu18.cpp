
#include "imu18.h"

void MPU6050Config (TwoWire &Wire)
{
  Wire.beginTransmission (0x68);
  Wire.write (0x6B);
  Wire.write (0x00);
  Wire.endTransmission ();
}

void GyroSignals (TwoWire &Wire, float& RateRoll, float& RatePitch, float& RateYaw, float& AccX, float& AccY, float& AccZ)
{
  Wire.beginTransmission (0x68);
  Wire.write (0x1A);
  Wire.write (0x05);
  Wire.endTransmission ();

  Wire.beginTransmission (0x68);
  Wire.write (0x1C);
  Wire.write(0x10);
  Wire.endTransmission();

  Wire.beginTransmission (0x68);
  Wire.write (0x3B);
  Wire.endTransmission ();
  Wire.requestFrom(0x68, 6);

  int16_t AccXLSB = Wire.read() << 8 | Wire.read();
  int16_t AccYLSB = Wire.read() << 8 | Wire.read();
  int16_t AccZLSB = Wire.read() << 8 | Wire.read();

  Wire.beginTransmission (0x68);
  Wire.write (0x1B);
  Wire.write (0x08);
  Wire.endTransmission ();

  Wire.beginTransmission (0x68);
  Wire.write (0x43);
  Wire.endTransmission ();
  Wire.requestFrom (0x68, 6);
  int16_t GyroX = Wire.read () <<8 | Wire.read ();
  int16_t GyroY = Wire.read () <<8 | Wire.read ();
  int16_t GyroZ = Wire.read () <<8 | Wire.read ();
  RateRoll = (float) GyroX / 65.5;
  RatePitch = (float) GyroY / 65.5;
  RateYaw = (float) GyroZ / 65.5;

  AccX = (float) AccXLSB / 4096;
  AccY = (float) AccYLSB / 4096;
  AccZ = (float) AccZLSB / 4096;

}

void GyroSignals (TwoWire &Wire, float& RateRoll, float& RatePitch, float& RateYaw, float& RateCalibrationRoll, float& RateCalibrationPitch, float& RateCalibrationYaw,
float& AccX, float& AccY, float& AccZ, float& AccCalibrationRoll, float& AccCalibrationPitch, float& AccCalibrationYaw, float& AngleRoll, float& AnglePitch)
{
  Wire.beginTransmission (0x68);
  Wire.write (0x1A);
  Wire.write (0x05);
  Wire.endTransmission ();

  Wire.beginTransmission (0x68);
  Wire.write (0x1C);
  Wire.write(0x10);
  Wire.endTransmission();

  Wire.beginTransmission (0x68);
  Wire.write (0x3B);
  Wire.endTransmission ();
  Wire.requestFrom(0x68, 6);

  int16_t AccXLSB = Wire.read() << 8 | Wire.read();
  int16_t AccYLSB = Wire.read() << 8 | Wire.read();
  int16_t AccZLSB = Wire.read() << 8 | Wire.read();

  Wire.beginTransmission (0x68);
  Wire.write (0x1B);
  Wire.write (0x08);
  Wire.endTransmission ();

  Wire.beginTransmission (0x68);
  Wire.write (0x43);
  Wire.endTransmission ();
  Wire.requestFrom (0x68, 6);
  int16_t GyroX = Wire.read () <<8 | Wire.read ();
  int16_t GyroY = Wire.read () <<8 | Wire.read ();
  int16_t GyroZ = Wire.read () <<8 | Wire.read ();
  RateRoll = (float) GyroX / 65.5 - RateCalibrationRoll;
  RatePitch = (float) GyroY / 65.5 - RateCalibrationPitch;
  RateYaw = (float) GyroZ / 65.5 - RateCalibrationYaw;

  AccX = ((float) AccXLSB / 4096) - AccCalibrationRoll;
  AccY = ((float) AccYLSB / 4096) - AccCalibrationPitch;
  AccZ = ((float) AccZLSB / 4096) - AccCalibrationYaw;

  AngleRoll = atan (AccY / sqrt (AccX * AccX + AccZ * AccZ)) * 1 / (3.142 / 180);
  AnglePitch = atan ( - AccX / sqrt (AccY * AccY + AccZ * AccZ)) * 1 / (3.142/180);  
}

void IMUCalibrationFunc (TwoWire &Wire, SECMEMS Rom, uint16_t RomFirstAdd, uint16_t IMUChannels, uint16_t EnaOffGPIO, uint16_t& RateCalibrationNumber, float& RateRoll,
float& RatePitch, float& RateYaw, float& RateCalibrationRoll, float& RateCalibrationPitch, float& RateCalibrationYaw, float& AccX, float& AccY, float& AccZ,
float& AccCalibrationRoll, float& AccCalibrationPitch, float& AccCalibrationYaw)
{
  int16_t Offsets[6];
  if (digitalRead (EnaOffGPIO) == LOW)
  {
    Serial.println ("IMU Calibration Process!");
    for (RateCalibrationNumber = 0; RateCalibrationNumber < 2000; RateCalibrationNumber ++)
    {
      GyroSignals (Wire, RateRoll, RatePitch, RateYaw, AccX, AccY, AccZ);
      RateCalibrationRoll += RateRoll;
      RateCalibrationPitch += RatePitch;
      RateCalibrationYaw += RateYaw;
      AccCalibrationRoll += AccX;
      AccCalibrationPitch += AccY;
      AccCalibrationYaw += AccZ;
      delay(1);
    }

    Offsets[0] = (int16_t) RateCalibrationRoll;
    Offsets[1] = (int16_t) RateCalibrationPitch;
    Offsets[2] = (int16_t) RateCalibrationYaw;
    Offsets[3] = (int16_t) AccCalibrationRoll;
    Offsets[4] = (int16_t) AccCalibrationPitch;
    Offsets[5] = (int16_t) AccCalibrationYaw;

    Serial.println ("Calibration: ");
    Serial.print ("RateCalibrationRoll: "); Serial.println (RateCalibrationRoll);
    Serial.print ("RateCalibrationPitch: "); Serial.println (RateCalibrationPitch);
    Serial.print ("RateCalibrationYaw: "); Serial.println (RateCalibrationYaw);
    Serial.print ("AccCalibrationRoll: "); Serial.println (AccCalibrationRoll);
    Serial.print ("AccCalibrationPitch: "); Serial.println (AccCalibrationPitch);
    Serial.print ("AccCalibrationYaw: "); Serial.println (AccCalibrationYaw);    

    StoringCalibVals (Wire, Rom, Offsets, RomFirstAdd, IMUChannels);
  }
  else
  {
    RequestCalibVals (Wire, Rom, Offsets, RomFirstAdd, IMUChannels);
    RateCalibrationRoll = (float) Offsets[0];
    RateCalibrationPitch = (float) Offsets[1];
    RateCalibrationYaw = (float) Offsets[2];
    AccCalibrationRoll = (float) Offsets[3];
    AccCalibrationPitch = (float) Offsets[4];
    AccCalibrationYaw = (float) Offsets[5];
  }

  Serial.println ("Storing: ");
  Serial.print ("Offsets[0]: "); Serial.println (Offsets[0]);
  Serial.print ("Offsets[1]: "); Serial.println (Offsets[1]);
  Serial.print ("Offsets[2]: "); Serial.println (Offsets[2]);
  Serial.print ("Offsets[3]: "); Serial.println (Offsets[3]);
  Serial.print ("Offsets[4]: "); Serial.println (Offsets[4]);
  Serial.print ("Offsets[5]: "); Serial.println (Offsets[5]);  

  RateCalibrationRoll /= 2000.0;
  RateCalibrationPitch /= 2000.0;
  RateCalibrationYaw /= 2000.0;
  AccCalibrationRoll /= 2000.0;
  AccCalibrationPitch /= 2000.0;
  AccCalibrationYaw = (AccCalibrationYaw / 2000.0) - 1.0;
  //while (1);  
}

bool StoringCalibVals (TwoWire &Wire, SECMEMS Rom, int16_t* Offsets, uint16_t RomFirstAdd, uint16_t IMUChannels)
{
  uint8_t Arr[2 * IMUChannels];

  for (uint8_t i = 0, j = 0; i < sizeof (Arr), j < IMUChannels; i += 2, j ++)
  {
    Arr[i] = Offsets[j] & 0xFF;
    Arr[i + 1] = (uint8_t) (Offsets[j] >> 8);
  }

  Rom.Write(Wire, RomFirstAdd, Arr, sizeof (Arr));

  Serial.println("\nStoring the IMU offset Values to EEPROM!");
  
  return (1);
}

bool RequestCalibVals (TwoWire &Wire, SECMEMS Rom, int16_t* Offsets, uint16_t RomFirstAdd, uint16_t IMUChannels)
{
  uint8_t Arr[2 * IMUChannels];

  Rom.Read (Wire, RomFirstAdd, Arr, sizeof(Arr));
  for (uint8_t i = 0, j = 0; i < IMUChannels, j < sizeof(Arr); i ++, j +=2) Offsets[i] = (((int16_t) Arr[j + 1]) << 8) | Arr[j];

  Serial.println ("\nReading Calib Values from EEPROM");

  return (1);
}

void Kalman1DFilter (float* Kalman1DOutput, float KalmanState, float KalmanUncertainty, float KalmanInput, float KalmanMeasurement, float TimeStep)
{
  KalmanState = KalmanState + TimeStep * KalmanInput;
  KalmanUncertainty = KalmanUncertainty + TimeStep * TimeStep * 4 * 4;
  float KalmanGain = KalmanUncertainty * 1.0 / (1.0 * KalmanUncertainty + 3.0 * 3.0);
  KalmanState = KalmanState + KalmanGain * (KalmanMeasurement - KalmanState);
  KalmanUncertainty = (1.0 - KalmanGain) * KalmanUncertainty;

  Kalman1DOutput[0] = KalmanState;
  Kalman1DOutput[1] = KalmanUncertainty;
}

void Kalman2DFilterSetup (BLA::Matrix<2,2>& F, BLA::Matrix<2,1>& G, BLA::Matrix<1,2>& H, BLA::Matrix<2,2>& I, BLA::Matrix<2,2>& Q,
BLA::Matrix<1,1>& R, BLA::Matrix<2,2>& P, BLA::Matrix<2,1>& S)
{
  BLA::Matrix<2,2> COE;
  COE = {100.0, 0.0, 0.0, 100.0};

  F = {1, 0.020, 0, 1};
  G = {0.5 * 0.020 * 0.020, 0.020};
  H = {1, 0};
  I = {1, 0, 0, 1};
  Q = G * ~G * COE;
  R = {30 * 30};
  P = {0, 0, 0, 0};
  S = {0, 0};
}


void Kalman2DFilter (BLA::Matrix<1,1>& Acc, float AccZInertial, BLA::Matrix<2,1>& S, BLA::Matrix<2,2> F, BLA::Matrix<2,1> G, BLA::Matrix<2,2>& P, BLA::Matrix<2,2> Q,
BLA::Matrix<1,1>& L, BLA::Matrix<1,2> H, BLA::Matrix<1,1> R, BLA::Matrix<2,1>& K, BLA::Matrix<1,1>& M, float AltitudeBarometer, float& AltitudeKalman,
float& VelocityVerticalKalman, BLA::Matrix<2,2> I)
{
  Acc = {AccZInertial};
  S = F * S + G * Acc;
  P = F * P * ~F + Q;
  L = H * P * ~H + R;

  BLA::Matrix<1,1> LINV;
  Invert(L, LINV);
  K = P * ~H * LINV;
  M = {AltitudeBarometer};
  S = S + K * (M - H * S);
  AltitudeKalman = S(0,0);
  VelocityVerticalKalman = S(1,0);
  P = (I - K * H) * P;
}

bool CalculAccZInertial (float& AccZInertial, float AnglePitch, float AngleRoll, float AccX, float AccY, float AccZ)
{
  AccZInertial = - sin (AnglePitch * (3.142 / 180)) * AccX + cos (AnglePitch * (3.142 / 180)) * sin (AngleRoll * (3.142 / 180)) * AccY + cos (AnglePitch * (3.142 / 180)) * cos (AngleRoll * (3.142 / 180)) * AccZ;
  AccZInertial = (AccZInertial - 1.0) * 9.81 * 100;  
  return (1);
}

bool LPFuncIMU (float* LPFvalsIMU, float* DataIMU, float TimeStep, float const OmeraZero)
{
  float const Acoe = (1.0 / OmeraZero) / ((1.0 / OmeraZero) + TimeStep);
  for (uint16_t i = 0; i < 3; i ++) LPFvalsIMU[i] = Acoe * LPFvalsIMU[i] + (1.0 - Acoe) * DataIMU[i];
  return (1);
}

