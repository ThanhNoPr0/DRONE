#ifndef _PID18_H_
#define _PID18_H_

#include <Arduino.h>

static float ReceiverValue[] = {0, 0, 0, 0, 0, 0, 0, 0};
static uint8_t ChannelNumber = 0;

static float TimeStep = 0.020;
static float DesiredRateRoll, DesiredRatePitch, DesiredRateYaw;
static float ErrorRateRoll, ErrorRatePitch, ErrorRateYaw;
static float InputRoll, InputThrottle, InputPitch, InputYaw;
static float PrevErrorRateRoll, PrevErrorRatePitch, PrevErrorRateYaw;
static float PrevItermRateRoll, PrevItermRatePitch, PrevItermRateYaw;
static float PIDReturn[] = {0, 0, 0};
static float PRateRoll = 0.6;
static float PRatePitch = PRateRoll;
static float PRateYaw = 2;
static float IRateRoll = 3.5;
static float IRatePitch = IRateRoll;
static float IRateYaw = 12;
static float DRateRoll = 0.03;
static float DRatePitch = DRateRoll;
static float DRateYaw = 0;
static float MotorInput1, MotorInput2, MotorInput3, MotorInput4;

static float DesiredAngleRoll, DesiredAnglePitch;
static float ErrorAngleRoll, ErrorAnglePitch;

static float PrevErrorAngleRoll, PrevErrorAnglePitch;
static float PrevItermAngleRoll, PrevItermAnglePitch;

static float PAngleRoll = 2; static float PAnglePitch = PAngleRoll;
static float IAngleRoll = 0; static float IAnglePitch = IAngleRoll;
static float DAngleRoll = 0; static float DAnglePitch = DAngleRoll;

static float DesiredVelocityVertical, ErrorVelocityVertical;
static float PVelocityVertical = 3.5;
static float IVelocityVertical = 0.0015;
static float DVelocityVertical = 0.01;
static float PrevErrorVelocityVertical, PrevItermVelocityVertical;

void PIDequation (float* PIDReturn, float Error, float P , float I, float D, float PrevError, float PrevIterm, float TimeStep);
void ResetPID (float& PrevErrorRateRoll, float& PrevErrorRatePitch, float& PrevErrorRateYaw, float& PrevItermRateRoll, float& PrevItermRatePitch, float& PrevItermRateYaw,
float& PrevErrorAngleRoll, float& PrevErrorAnglePitch, float& PrevItermAngleRoll, float& PrevItermAnglePitch, float& PrevErrorVelocityVertical, float& PrevItermVelocityVertical);


static float ErrorAccRoll, ErrorAccPitch;
static float PrevErrorAccRoll, PrevErrorAccPitch;
static float PrevItermAccRoll, PrevItermAccPitch;
static float PAccRoll = 1.1;
static float PAccPitch = PAccRoll;
static float IAccRoll = 0.0;
static float IAccPitch = IAccRoll;
static float DAccRoll = 0.0;
static float DAccPitch = DAccRoll;
static float AccAngleRoll, AccAnglePitch;
void ResetAccPID (float& PrevErrorAccRoll, float& PrevItermAccRoll);

#endif
