
#include "fcuq18.h"

void setup ()
{
  FCUQconfig (IIC, ENABLE_OFFSET_PIN, CAP_TIME_GPIO, LED_BEGINNING_SETUP, LED_RECEIVING_POWER, LED_OPERATION_PROCESS, CapTime);
  rcConfig ();
  PWMPortReset ();
  ESCPWMConfig ();
  ESCcalib (); 
  EEprom.Begin ();
  MPU6050Config (IIC);
  IMUCalibrationFunc (IIC, EEprom, IMU_OFFSETS_SECMEMS_FIRST_ADD, IMU_CHANNELS, ENABLE_OFFSET_PIN, RateCalibrationNumber, RateRoll,
  RatePitch, RateYaw, RateCalibrationRoll, RateCalibrationPitch, RateCalibrationYaw, AccX, AccY, AccZ, AccCalibrationRoll, AccCalibrationPitch, AccCalibrationYaw);
  BarometerConfig (IIC);
  BarometerCalib (IIC, AltitudeBarometerStartUp, AltitudeBarometer, dig_T1, dig_P1, dig_T2, dig_T3, dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9);
  Kalman2DFilterSetup (F, G, H, I, Q, R, P, S);
  DataComConfig (UCOM, UCOM_BAUDRATE);
  CheckingRCVals (); 
  Serial.println("Beginning!");
  LoopTimer = micros();
}
  
void loop ()
  {}
// void loop ()
// {
  // ReceivControlData (UCOM, ReceiverValue, BSNCBuff, BSNCData, QuadBuff, DATA_BLOCK, UCOM_CTS_GPIO, UCOM_RTS_GPIO, RC_CHANNELS, RC_DATA_POS_MIN);

  // GyroSignals (IIC, RateRoll, RatePitch, RateYaw, RateCalibrationRoll, RateCalibrationPitch, RateCalibrationYaw,
  // AccX, AccY, AccZ, AccCalibrationRoll, AccCalibrationPitch, AccCalibrationYaw, AngleRoll, AnglePitch);

  // Kalman1DFilter (Kalman1DOutput, KalmanAngleRoll, KalmanUncertaintyAngleRoll, RateRoll, AngleRoll, TimeStep);
  // KalmanAngleRoll = Kalman1DOutput[0];
  // KalmanUncertaintyAngleRoll = Kalman1DOutput[1];

  // Kalman1DFilter(Kalman1DOutput, KalmanAnglePitch,KalmanUncertaintyAnglePitch, RatePitch, AnglePitch, TimeStep);
  // KalmanAnglePitch = Kalman1DOutput[0];
  // KalmanUncertaintyAnglePitch = Kalman1DOutput[1];

  // DesiredAngleRoll = 0.10 * (ReceiverValue[0] * (ReceiverValue[4] / 1000.0 - 1.0) - 1500.0);
  // DesiredAnglePitch = 0.10 * (ReceiverValue[1] * (ReceiverValue[4] / 1000.0 - 1.0) - 1500.0);
  // DesiredRateYaw = 0.15 * (ReceiverValue[2] * (ReceiverValue[4] / 1000.0 - 1.0) - 1500.0);
  // InputThrottle = ReceiverValue[3] * (ReceiverValue[5] / 1000.0 - 1.0);

  // ErrorAngleRoll = DesiredAngleRoll - KalmanAngleRoll;
  // ErrorAnglePitch = DesiredAnglePitch - KalmanAnglePitch;

  // PIDequation (PIDReturn, ErrorAngleRoll, PAngleRoll, IAngleRoll, DAngleRoll, PrevErrorAngleRoll, PrevItermAngleRoll, TimeStep);
  // DesiredRateRoll = PIDReturn[0];
  // PrevErrorAngleRoll = PIDReturn[1];
  // PrevItermAngleRoll = PIDReturn[2];

  // PIDequation (PIDReturn, ErrorAnglePitch, PAnglePitch, IAnglePitch, DAnglePitch, PrevErrorAnglePitch, PrevItermAnglePitch, TimeStep);
  // DesiredRatePitch = PIDReturn[0];
  // PrevErrorAnglePitch = PIDReturn[1];
  // PrevItermAnglePitch  = PIDReturn[2];

  // ErrorRateRoll = DesiredRateRoll - RateRoll;
  // ErrorRatePitch = DesiredRatePitch - RatePitch;
  // ErrorRateYaw = DesiredRateYaw - RateYaw;

  // PIDequation (PIDReturn, ErrorRateRoll, PRateRoll, IRateRoll, DRateRoll, PrevErrorRateRoll, PrevItermRateRoll, TimeStep);
  // InputRoll = PIDReturn[0];
  // PrevErrorRateRoll = PIDReturn[1];
  // PrevItermRateRoll = PIDReturn[2];

  // PIDequation (PIDReturn, ErrorRatePitch, PRatePitch, IRatePitch, DRatePitch, PrevErrorRatePitch, PrevItermRatePitch, TimeStep);
  // InputPitch = PIDReturn[0];
  // PrevErrorRatePitch = PIDReturn[1];
  // PrevItermRatePitch = PIDReturn[2];

  // PIDequation (PIDReturn, ErrorRateYaw, PRateYaw, IRateYaw, DRateYaw, PrevErrorRateYaw, PrevItermRateYaw, TimeStep);
  // InputYaw = PIDReturn[0];
  // PrevErrorRateYaw = PIDReturn[1];
  // PrevItermRateYaw = PIDReturn[2];

  // AssignMotorInput (ReceiverValue, InputRoll, InputPitch, InputYaw, InputThrottle, MotorInput1, MotorInput2, MotorInput3, MotorInput4,
  // PrevErrorRateRoll, PrevErrorRatePitch, PrevErrorRateYaw, PrevItermRateRoll, PrevItermRatePitch, PrevItermRateYaw,
  // PrevErrorAngleRoll, PrevErrorAnglePitch, PrevItermAngleRoll, PrevItermAnglePitch, PrevErrorVelocityVertical, PrevItermVelocityVertical);

  // DutyCyc[0] = MotorInput1;
  // DutyCyc[1] = MotorInput2;
  // DutyCyc[2] = MotorInput3;
  // DutyCyc[3] = MotorInput4;
  // UpdateESCSimultaneous (DutyCyc, DutyRef, PWM_CHANNELS);

  // UpdateQuadData (ReceiverValue, QuadBuff, QuadData, DutyRef, KalmanAngleRoll, KalmanAnglePitch, RateYaw, InputThrottle, RC_DATA_POS_MIN, DATA_BLOCK);

  // while (micros () - LoopTimer < 20000);
  // LoopTimer = micros();  
  
  // CapTime = !CapTime;
  // digitalWrite (CAP_TIME_GPIO, CapTime);
  // digitalWrite (LED_OPERATION_PROCESS, CapTime);

// }

                                                                                                                                                                                                                        